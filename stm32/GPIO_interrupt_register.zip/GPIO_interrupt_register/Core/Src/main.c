#include"main.h"
#include<stm32f4xx.h>
void EXTI15_10_IRQHandler(void)//Request Handler
{
   GPIOA->ODR ^= 0x20;//ISR functionality
   for(int i=0;i<3000000;i++);//Delay
	   EXTI->PR |= 0x2000; //Return back from ISR to Main prog
}
int main()
{
   __disable_irq();//Disable the IRQ
   RCC->AHB1ENR |= 0x5; //Enable clock for PA & PC
   GPIOA->MODER |= 0x400; //Set out put for PA
   RCC->APB2ENR |= 0x4000;
   SYSCFG->EXTICR[3] |= 0x20;// Enable SYSCFG for Trigger the interrupt
   EXTI->IMR |= 0x2000;// Make mask pin set to 1 of corresponding IRQ - PIN
   EXTI->RTSR |= 0x2000;// Trigger the interrupt on Falling edge
   NVIC_EnableIRQ(EXTI15_10_IRQn);//Generate IRQ
   __enable_irq(); //Enable the Request Line
   while(1);
}
